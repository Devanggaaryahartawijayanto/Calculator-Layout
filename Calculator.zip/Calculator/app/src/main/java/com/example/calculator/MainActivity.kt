package com.codingformobile.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import org.mariuszgromada.math.mxparser.Expression
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Clear button
        button_clear.setOnClickListener {
            input.text = ""
            output.text = ""
        }

        // Number buttons
        button_0.setOnClickListener { appendToInputText("0") }
        button_1.setOnClickListener { appendToInputText("1") }
        button_2.setOnClickListener { appendToInputText("2") }
        button_3.setOnClickListener { appendToInputText("3") }
        button_4.setOnClickListener { appendToInputText("4") }
        button_5.setOnClickListener { appendToInputText("5") }
        button_6.setOnClickListener { appendToInputText("6") }
        button_7.setOnClickListener { appendToInputText("7") }
        button_8.setOnClickListener { appendToInputText("8") }
        button_9.setOnClickListener { appendToInputText("9") }

        // Operator buttons
        button_bagi.setOnClickListener { appendToInputText("÷") }
        button_kali.setOnClickListener { appendToInputText("×") }
        button_tambah.setOnClickListener { appendToInputText("+") }
        button_kurang.setOnClickListener { appendToInputText("-") }

        // Equals button
        button_equal.setOnClickListener { showResult() }
    }

    private fun appendToInputText(buttonValue: String) {
        input.text = "${input.text}$buttonValue"
    }

    private fun getInputExpression(): String {
        var expression = input.text.toString()
        expression = expression.replace("÷", "/")
        expression = expression.replace("×", "*")
        return expression
    }

    private fun showResult() {
        try {
            val expression = getInputExpression()
            val result = Expression(expression).calculate()
            if (result.isNaN()) {
                // Show Error Message
                output.text = "Error"
                output.setTextColor(ContextCompat.getColor(this, R.color.red))
            } else {
                // Show Result
                output.text = DecimalFormat("0.######").format(result).toString()
                output.setTextColor(ContextCompat.getColor(this, R.color.green))
            }
        } catch (e: Exception) {
            // Show Error Message
            output.text = "Error"
            output.setTextColor(ContextCompat.getColor(this, R.color.red))
        }
    }
}
